init;
[V,D]=eig(A')
p=A'*q
